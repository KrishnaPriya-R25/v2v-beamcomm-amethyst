# Test Plan

Run only on a controlled bench. Record the actual hardware, distance, angle, ambient light, and results. The cases below are planned tests, not claims of completed testing.

| ID | Test | Procedure | Expected result |
|---|---|---|---|
| TC-01 | Power-on | Power both units and open serial monitors | Receiver shows “BeamComm Ready”; transmitter prints ready message |
| TC-02 | Basic message | Send `CAUTION` at close range with aligned optics | Receiver displays the message and sounds a short alert |
| TC-03 | Emergency text | Send `BRAKE FAILURE` | Receiver displays the decoded text and alerts |
| TC-04 | Maximum length | Send a message of 24 printable characters | Message is transmitted without writing beyond the configured buffer |
| TC-05 | Empty input | Press Enter without typing text | Transmitter sends no message |
| TC-06 | Misalignment | Slowly rotate or offset the receiver | Reception may fail; document the threshold rather than assuming success |
| TC-07 | Increased distance | Increase distance in measured increments | Record successful and missed frames at each distance |
| TC-08 | Ambient light | Repeat under indoor light and brighter ambient conditions | Record whether decoding reliability changes |
| TC-09 | Receiver disconnected | Block or disconnect the optical receiver | No valid message should be reported |
| TC-10 | LCD/buzzer | Receive a valid message | LCD shows text and buzzer sounds briefly |

## Results template
For each run record:
- Date/time:
- Hardware/module model:
- Distance and angle:
- Lighting conditions:
- Message sent:
- Message received correctly (yes/no):
- Alert output (yes/no):
- Notes / observed failures:

## Acceptance criteria
For a basic bench demo, require correct receipt of each sample message over 10 consecutive attempts at a documented short distance. This is a proposed criterion; do not report it as achieved until the tests are run. For safety-related use, this criterion is not sufficient.
