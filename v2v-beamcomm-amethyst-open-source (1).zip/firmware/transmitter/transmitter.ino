/*
  V2V BeamComm — Transmitter (educational bench prototype)
  Sends ASCII messages as simple pulse-width-coded light.
  Use a transistor/LED driver stage; do not drive high-power LEDs directly.
*/
const uint8_t TX_PIN = 3;
const unsigned int START_MARK_US = 3000;
const unsigned int BIT_MARK_US = 500;
const unsigned int ZERO_SPACE_US = 500;
const unsigned int ONE_SPACE_US = 1500;
const unsigned int INTER_BIT_GAP_US = 500;
const size_t MAX_MESSAGE_LEN = 24;

void sendMark(unsigned int durationUs) {
  digitalWrite(TX_PIN, HIGH);
  delayMicroseconds(durationUs);
  digitalWrite(TX_PIN, LOW);
}

void sendByte(uint8_t value) {
  for (int bit = 7; bit >= 0; --bit) {
    sendMark(BIT_MARK_US);
    delayMicroseconds((value & (1U << bit)) ? ONE_SPACE_US : ZERO_SPACE_US);
    delayMicroseconds(INTER_BIT_GAP_US);
  }
}

void sendMessage(const char* message) {
  sendMark(START_MARK_US);
  delayMicroseconds(1000);
  for (size_t i = 0; message[i] != '\0' && i < MAX_MESSAGE_LEN; ++i) {
    sendByte((uint8_t)message[i]);
  }
  // Terminator byte: receiver uses it to finish the frame.
  sendByte((uint8_t)'\n');
  digitalWrite(TX_PIN, LOW);
}

void setup() {
  pinMode(TX_PIN, OUTPUT);
  digitalWrite(TX_PIN, LOW);
  Serial.begin(9600);
  Serial.println(F("V2V BeamComm transmitter ready. Type an alert and press Enter."));
}

void loop() {
  static char message[MAX_MESSAGE_LEN + 1];
  static size_t length = 0;
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      if (length > 0) {
        message[length] = '\0';
        sendMessage(message);
        Serial.print(F("Sent: "));
        Serial.println(message);
        length = 0;
      }
    } else if (length < MAX_MESSAGE_LEN && c >= 32 && c <= 126) {
      message[length++] = c;
    }
  }
}
