/*
  V2V BeamComm — Receiver (educational bench prototype)
  Requires a digital-output optical receiver and LiquidCrystal_I2C library.
  Timing is illustrative and may need calibration for the selected hardware.
*/
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

const uint8_t RX_PIN = 2;
const uint8_t BUZZER_PIN = 8;
const unsigned long START_THRESHOLD_US = 2200;
const unsigned long BIT_MARK_MIN_US = 250;
const unsigned long BIT_MARK_MAX_US = 900;
const unsigned long ZERO_SPACE_MAX_US = 900;
const unsigned long ONE_SPACE_MIN_US = 1000;
const size_t MAX_MESSAGE_LEN = 24;

// Change 0x27 if your LCD backpack uses another I2C address.
LiquidCrystal_I2C lcd(0x27, 16, 2);

bool waitForEdge(uint8_t targetLevel, unsigned long timeoutUs, unsigned long &durationUs) {
  unsigned long start = micros();
  while (digitalRead(RX_PIN) != targetLevel) {
    if (micros() - start > timeoutUs) return false;
  }
  unsigned long edgeStart = micros();
  while (digitalRead(RX_PIN) == targetLevel) {
    if (micros() - edgeStart > timeoutUs) return false;
  }
  durationUs = micros() - edgeStart;
  return true;
}

bool readBit(bool &bitValue) {
  unsigned long markDuration = 0;
  // This assumes HIGH represents received light. Invert logic if your module differs.
  if (!waitForEdge(HIGH, 50000, markDuration)) return false;
  if (markDuration > START_THRESHOLD_US) return false; // start marker, not a data bit
  if (markDuration < BIT_MARK_MIN_US || markDuration > BIT_MARK_MAX_US) return false;

  unsigned long spaceDuration = 0;
  if (!waitForEdge(LOW, 50000, spaceDuration)) return false;
  if (spaceDuration >= ONE_SPACE_MIN_US) bitValue = true;
  else if (spaceDuration <= ZERO_SPACE_MAX_US) bitValue = false;
  else return false;
  return true;
}

void alertMessage(const char* message) {
  lcd.clear();
  lcd.setCursor(0, 0);
  for (uint8_t i = 0; i < 16 && message[i] != '\0'; ++i) lcd.print(message[i]);
  lcd.setCursor(0, 1);
  for (uint8_t i = 16; i < 32 && message[i] != '\0'; ++i) lcd.print(message[i]);

  digitalWrite(BUZZER_PIN, HIGH);
  delay(250);
  digitalWrite(BUZZER_PIN, LOW);
  Serial.print(F("Received: "));
  Serial.println(message);
}

void setup() {
  pinMode(RX_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  Serial.begin(9600);
  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(F("BeamComm Ready"));
  Serial.println(F("V2V BeamComm receiver ready."));
}

void loop() {
  // This compact example shows the timing approach, but robust framing needs
  // calibration for the actual optical receiver and should be validated on a bench.
  unsigned long markDuration = 0;
  if (!waitForEdge(HIGH, 100000, markDuration)) return;
  if (markDuration < START_THRESHOLD_US) return;

  char message[MAX_MESSAGE_LEN + 1];
  size_t length = 0;
  bool frameOk = true;

  while (length < MAX_MESSAGE_LEN) {
    uint8_t value = 0;
    for (uint8_t bit = 0; bit < 8; ++bit) {
      bool bitValue = false;
      if (!readBit(bitValue)) {
        frameOk = false;
        break;
      }
      value = (uint8_t)((value << 1) | (bitValue ? 1 : 0));
    }
    if (!frameOk) break;
    if (value == (uint8_t)'\n') {
      message[length] = '\0';
      if (length > 0) alertMessage(message);
      return;
    }
    if (value < 32 || value > 126) {
      frameOk = false;
      break;
    }
    message[length++] = (char)value;
  }
  if (!frameOk || length >= MAX_MESSAGE_LEN) {
    Serial.println(F("Invalid/incomplete frame; ignored."));
  }
}
