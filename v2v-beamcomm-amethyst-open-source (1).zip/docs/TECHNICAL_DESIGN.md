# Technical Design Document — V2V BeamComm

## 1. Purpose
Demonstrate a direct light-based message path between two compatible bench units for short vehicle-emergency alerts. This is a student prototype, not a certified automotive safety product.

## 2. Architecture
```mermaid
flowchart LR
  A[Emergency input / Serial Monitor] --> B[Transmitter Arduino]
  B --> C[LED driver + light source]
  C --> D[Optical line-of-sight channel]
  D --> E[Digital optical receiver]
  E --> F[Receiver Arduino]
  F --> G[16x2 LCD]
  F --> H[Audio buzzer]
```

## 3. Components
- Transmitter Arduino Uno
- Receiver Arduino Uno
- LED with suitable current limiting and driver stage
- Optical receiver module with digital output
- 16×2 I²C LCD and active buzzer
- Power, wiring and USB serial connections

Exact modules and their electrical characteristics must be recorded for the final build.

## 4. Data flow
1. Operator enters a short ASCII alert in the transmitter Serial Monitor.
2. Firmware emits a start marker followed by each character as eight MSB-first bits.
3. Each bit consists of a light mark followed by a short or long space.
4. Receiver attempts to detect the start marker and decode bytes.
5. A newline byte terminates the message; valid printable messages are displayed and trigger a short buzzer alert.

## 5. Interfaces and configuration
- Transmitter signal output: digital pin 3 (to a driver stage).
- Receiver digital signal input: pin 2.
- Active buzzer signal: pin 8.
- LCD: I²C, default address `0x27`.
- Serial baud rate: 9600.
- Timing constants are in the firmware source and require calibration for the actual modules.

No environment variables are required. Firmware settings are compile-time constants.

## 6. Error handling
- Invalid or incomplete frames should be ignored.
- The current example has limited framing and no checksum, acknowledgement, authentication or collision avoidance.
- For a more robust version, add a preamble, message length, checksum/CRC, timeout handling and a defined retransmission policy.

## 7. Security and safety
- Messages are not authenticated; a nearby light source could interfere with reception.
- Optical communication requires sufficient line of sight and is affected by sunlight, weather, distance and alignment.
- Do not rely on this prototype for driving decisions or emergency response.
- Perform all tests on a bench, never on public roads.

## 8. Future improvements
- Add CRC/checksum and explicit frame length.
- Calibrate and document range, angle tolerance and ambient-light performance.
- Add sensor-triggered alerts only after validating the sensor and fail-safe behaviour.
- Consider message priority, duplicate suppression and authenticated messages.
